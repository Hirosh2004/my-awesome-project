# My Awesome Project 🚀

This is a simple JavaScript project that welcomes users with a personalized greeting.

## Features

- Prints a welcome message
- Greets users by name
- Clean, minimal, and customizable

## Usage

```bash
node index.js
```
