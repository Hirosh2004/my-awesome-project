console.log("This is my awesome project!");

function greet(name) {
  return `Hello, ${name}! Welcome to My Awesome Project.`;
}

console.log(greet("Visitor"));
